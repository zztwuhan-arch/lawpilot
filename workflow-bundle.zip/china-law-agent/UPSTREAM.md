# 上游来源

https://github.com/CSlawyer1985/claude-for-legal-ZH

提交：171903c9e5e91b3b7625f1dd557d146ba5a25adc

upstream/ 为该提交的工作流快照，保留上游 LICENSE 和版权声明；排除了 Git 元数据及其他运行时适配入口。自定义 Codex 入口、路由和事项管理由本项目新增。工作流快照不自动更新，不代表已验证法律内容或已连接 MCP。
