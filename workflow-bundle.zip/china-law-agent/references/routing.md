# 领域路由

以下路径相对技能根目录 upstream/。工作流不存在时报告，不编造同名能力。
- 合同、NDA、SaaS、续约：`commercial-legal` → review, amendment-history, renewal-tracker。
- 诉讼、证据、律师函、案件进度：`litigation-legal` → chronology, claim-chart, brief-section-drafter, demand-intake, demand-draft, demand-received, matter-intake。
- 刑事证据与辩护：`criminal-legal` → case-analysis, defense-strategy, bail-application。
- 劳动用工与内部调查：`employment-legal` → hiring-review, termination-review, internal-investigation, policy-drafting。
- 并购尽调、公司治理：`corporate-legal` → tabular-review, diligence-issue-extraction, board-minutes, written-consent, closing-checklist。
- 个人信息、数据处理：`privacy-legal` → dpa-review, pia-generation, dsar-response。
- 产品上线、广告宣传：`product-legal` → launch-review, marketing-claims-review, feature-risk-assessment。
- AI应用与供应商合规：`ai-governance-legal` → use-case-triage, vendor-ai-review, policy-starter。
- 知识产权与开源：`ip-legal` → infringement-triage, oss-review, ip-clause-review。
- 法规变化与制度整改：`regulatory-legal` → reg-feed-watcher, policy-diff, policy-redraft。
- 法学学习：`law-student` → case-brief, irac-practice, study-plan。
- 法律诊所：`legal-clinic` → client-intake, memo, draft。
- 用户明确要求法律技能维护：`legal-builder-hub` → skills-qa, skill-manager。
